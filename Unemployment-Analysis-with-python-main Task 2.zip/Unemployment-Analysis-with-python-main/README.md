# Unemployment-Analysis-with-python
Unemployment Analysis in India using python


Unemployment is measured by the unemployment rate which is the number of people who are unemployed as a percentage of the total labour force. We have seen a sharp increase in the unemployment rate during Covid-19, so analyzing the unemployment rate can be a good data science project. In this project, let's walk through the task of Unemployment analysis with Python.

## Unemployment Analysis with Python
The unemployment rate is calculated based on a particular region, so to analyze unemployment we will be using an unemployment dataset of India. The dataset I’m using here contains data on India’s unemployment rate during Covid-19. 
